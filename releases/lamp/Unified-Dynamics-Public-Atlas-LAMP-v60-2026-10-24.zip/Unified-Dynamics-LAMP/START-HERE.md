# Unified Dynamics — standalone LAMP deployment

Exported 24 October 2026 from **Sites version 60**.
Source commit: `0337cb240a042c2dcabfb83b4d5564483d6c458b`.

This is the complete current project: **50 HTML pages, 1,105 published web files,
and all 1,224 tracked source files**. The web files include local assets, search
indexes, research data, PDFs, source downloads, and existing release ZIPs.

The atlas runs as ordinary static files on Apache. **No PHP, MySQL, Composer,
Node server, Cloudflare service, visitor login, or build step is required on the
webhost.** JavaScript runs in the visitor's browser. Serve over HTTP/HTTPS;
opening index.html directly as a file will not support JSON-backed search.

## Upload to a domain or subdomain root

1. Unzip this package on your computer.
2. Optional but recommended: set your new domain's sitemap before upload:

   ```bash
   python3 tools/configure_deployment.py --origin https://research.example.org
   ```

   Replace the example with your actual domain. This tool runs on your computer;
   Python is not needed on the webhost. Skip this step if you only need to test
   the site immediately; the original sitemap will still name the Sites domain.
3. In cPanel File Manager, FTP, or SFTP, open the domain's document root, usually
   `public_html/` or a domain-specific folder. Back up any existing site there.
4. Upload **the contents of this package's `public_html/` folder**, including
   `.htaccess`, into that document root. `index.html`, `assets/`, `sources/`, and
   the route directories must be immediately inside the document root.
5. Use directory permissions `755` and file permissions `644` if your host asks.
6. Enable HTTPS through the host's control panel, then visit the domain.
7. Open Foundations, Papers, Research archive, and Search sources. Search for
   `tetrahedron`, open a provenance detail, and follow a local source or PDF link.

Do not upload the entire outer package into the web directory. `source/`,
`tools/`, `reports/`, and the manifests are for offline maintenance and review.
If your host already has an `index.php` or `index.html`, move the old entry point
aside as part of your backed-up deployment so it cannot take precedence.

## Upload beneath a path such as /UD/

The original release uses domain-root URLs. Configure a deployment copy first:

```bash
python3 tools/configure_deployment.py --base-path /UD --origin https://example.org
python3 tools/verify_package.py
```

Then upload the **contents** of `public_html/` into your host's `public_html/UD/`.
The resulting URL will be `https://example.org/UD/`. Path spelling and case must
match. Nested paths such as `/research/UD` are also supported. This is not a
server-side rewrite and does not require `mod_rewrite`.

The configuration tool adjusts HTML navigation, the shared browser fetch/link
helper, and sitemap/robots URLs. Research downloads and JSON provenance data
stay byte-identical. The full original release always remains in `source/dist/`.
The tool can be rerun for another destination; it regenerates presentation files
from that original release. Do not edit the deployment copy before reconfiguring.

To reset to the original domain-root files:

```bash
python3 tools/configure_deployment.py
```

To reset to a root deployment with your new sitemap:

```bash
python3 tools/configure_deployment.py --origin https://research.example.org
```

## What is included

| Path | Purpose |
| --- | --- |
| `public_html/` | Ready-to-upload website; domain-root layout by default |
| `public_html/.htaccess` | Static index, file MIME types, and response headers |
| `source/` | Complete tracked project source at the recorded commit, including original `dist/` |
| `tools/configure_deployment.py` | Optional subdirectory and sitemap configuration |
| `tools/verify_package.py` | Link, anchor, data, source-hash, and JavaScript checks |
| `EXPORT-MANIFEST.json` | Version, commit, and SHA-256 hashes of original source/web files |
| `SHA256SUMS.txt` | Integrity hashes of every other package file |
| `reports/` | Root/subdirectory validation and browser smoke-test results |

The source includes historical build and verification scripts. Deploy the
preserved `public_html/` directly. Historical generators may require external
input snapshots and must not be replayed over later amendments without following
`source/README.md` and `source/AGENTS.md`. Git history is not included; current
tracked source is included in full. Repository credentials, runtime secrets,
and host configuration are not part of this export.

## Verification and practical limits

Both root and `/UD/` layouts passed checks over all 50 pages, 1,824 local links
and fragments, 375 JSON files, and 29 JavaScript modules/scripts. Original source
and web bytes are hash-checked. The `/UD/` browser smoke test confirmed navigation,
search data loading, filtering, provenance details, and prefixed download links.
It is a smoke test, not exhaustive testing of every interactive research tool.

Apache is not installed in the export environment, so `.htaccess` has not been
executed on Apache here. If your shared host returns HTTP 500, inspect its error
log. Hosts can restrict `DirectoryIndex`, `AddType`, or `Header` in `.htaccess`.
Your host can apply the equivalent settings in its panel, or you can temporarily
rename `.htaccess` to isolate that issue. The site uses ordinary directory indexes
and needs no rewrite/front-controller rules. Its research `.py`, `.tex`, and `.md`
files are downloadable source text, not server applications.

External citations (GitHub, ORCID, the historical portal, and other linked
research) remain external links. This export contains every file shipped with the
selected project; it does not recursively mirror every referenced website.
Existing missing-source labels and research qualifications remain preserved.
This standalone copy will not receive future Sites updates automatically.

For optional local verification, use Python 3.9+ and Node.js for JavaScript syntax
checks. Neither is required in production. The verifier records when Node is
unavailable. You can verify archive contents with `sha256sum -c SHA256SUMS.txt`
before making deployment-specific changes.
