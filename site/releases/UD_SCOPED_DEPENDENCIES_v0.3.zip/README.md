# UD scoped dependencies v0.3

Public explorer: https://unified-dynamics-public.ben-w-mayes.chatgpt.site/dependencies/

Extract this archive and run `python verify_dependencies.py` to replay the constructor checks using only the Python standard library. Node can syntax-check the supplied JavaScript. UI files are review copies with links to the complete public atlas; this archive is not a standalone copy of the entire atlas.

The build script requires the full Site source checkout at its preserved reading edition 0.2 baseline. Source-text snapshots are extracted atlas content; original portal package byte recovery is not claimed. All declared source limitations are retained in the graph and report.

Graph completeness applies only to its declared finite targets. The full research proof DAG and independent human review remain open. Hypothetical change drills do not alter scientific registry statuses. Physical promotion: 0.
