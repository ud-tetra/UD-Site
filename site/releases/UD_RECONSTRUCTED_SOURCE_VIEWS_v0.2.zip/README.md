# DistinctionDynamics Full Repository — substantive reading archive v0.2

The original v1 ZIP has 55 placeholder members. Its original bytes are preserved, not silently overwritten. The new reading archive supplies 55 source-linked replacement notes, the original ZIP, and a recovery manifest. No lost script or historical proof is claimed recovered.

Each note defines the actual current related object, cites versions, lists relevant ledger rows and states the missing original/reopening condition. Simulation and dated-log entries remain source-blocked, with substantive audit notes rather than fabricated run code/history.

Use the four current papers for the current scientific spine. All physical correspondence remains unpromoted. The full proof-dependency DAG is OPEN_GATED.
