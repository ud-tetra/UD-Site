"""Public same-constructor probes; not a blind campaign or independent review."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import copy,json,math,importlib.util
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_validator',R/'captures/2026-10-19T130822Z-codex-parity-contract-50d3c586/validate_candidate.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def run():
    a,p=v.source();case=v.canonical(a,p);results={}
    def record(name,q,status,gate=None):
        out=v.validate(q,a,p)
        if out['status']!=status or gate and out.get('gates',{}).get(gate) is not False:
            raise AssertionError((name,out))
        results[name]=out
    record('native_reference',case,'NUMERICAL_SOURCE_ADMITTED')
    for label,c in [('lower_boundary',.001),('upper_boundary',1000.)]:
        record(label,v.canonical(a,p,c),'NUMERICAL_SOURCE_ADMITTED')
    for label,c in [('below_lane',math.nextafter(.001,0.)),('above_lane',math.nextafter(1000.,math.inf)),('negative',-1.),('zero',0.),('not_finite',float('nan'))]:
        q=copy.deepcopy(case);q['c']=c;record(label,q,'INELIGIBLE')
    def changed_frame(frame):
        q=copy.deepcopy(case);q['W']=frame;q['T']=v.tr(frame)
        rr=[[float((1 if i<3 else -1) if i==j else 0) for j in range(6)] for i in range(6)]
        q['Theta']=v.mm(v.mm(frame,rr),v.tr(frame));return q
    # A noncanonical complex frame is allowed: no canonical-frame or physical sign uniqueness follows.
    jj=[[float(-1 if j==i+3 else 1 if i==j+3 else 0) for j in range(6)] for i in range(6)]
    record('allowed_quarter_turn_frame',changed_frame(v.mm(case['W'],jj)),'NUMERICAL_SOURCE_ADMITTED')
    swap=[[float(j==(i+3)%6) for j in range(6)] for i in range(6)]
    record('anti_symplectic_copy_swap',changed_frame(v.mm(case['W'],swap)),'REJECTED','native_generator')
    # Opposite selector root: same Hodge frequency and Darboux convention, different selected sector.
    exact=next(x for x in v.CONTRACT['source_pins'] if x['path'].endswith('exact_selector_check.py'))
    ss=importlib.util.spec_from_file_location('source_reconstruction',R/exact['path']);m=importlib.util.module_from_spec(ss);ss.loader.exec_module(m)
    _,(_,p0,p1)=m.verify()
    upper=[[float(x)-math.sqrt(8065)*float(y) for x,y in zip(row,other)] for row,other in zip(p0,p1)]
    u=[[0.]*3 for _ in range(30)]
    for j,(seed,den) in enumerate(zip(([1,-1,0,0],[1,1,-2,0],[1,1,1,-3]),(2,6,12))):
        for i,x in enumerate(seed):u[i][j]=x/math.sqrt(den)
    q=v.scale(v.mm(upper,u),1/math.sqrt((1-89/math.sqrt(8065))/2))
    pp=v.scale(v.mm(a,q),1/math.sqrt(5));w=[x+y for x,y in zip(q,pp)]
    upper_case=changed_frame(w);record('opposite_response_sector',upper_case,'REJECTED','selected_membership')
    assert results['opposite_response_sector']['gates']['native_generator']
    assert results['opposite_response_sector']['gates']['Darboux_pullback']
    record('coordinate_carrier',changed_frame([[float(i==j) for j in range(6)] for i in range(30)]),'REJECTED','selected_membership')
    return {'classification':'CONSTRUCTOR_DEVELOPMENT_PROBES_ONLY','case_count':len(results),'results':results,'independent_review':False,'physical_promotion':0}
if __name__=='__main__':print(json.dumps(run(),indent=2))
