"""Constructor QA of review transport, not an attestation."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import copy,json,tempfile,hashlib,shutil,subprocess
from check_return import check
R=Path(__file__).resolve().parent

def main():
    template=json.loads((R/'REVIEW_RETURN_TEMPLATE.json').read_text());tests={}
    assert check(template,R)['status']=='NOT_READY';tests['unfilled_return']='rejected'
    q=copy.deepcopy(template);q.update(status='SUBMITTED',reviewed_at_utc='2026-10-19T15:13:16Z',methods=['static_inspection'],attestation='CONSTRUCTOR_TEST_FIXTURE_NOT_A_REVIEW')
    q['reviewer']={'identifier':'CONSTRUCTOR_TEST_FIXTURE','kind':'constructor_team','relationship_to_constructor':'same team','independence_declaration':'not independent; fixture only'}
    out=check(q,R);assert out['status']=='RETURN_STRUCTURALLY_COMPLETE' and out['scientific_findings']=='NOT_ADJUDICATED';tests['partial_static_return']='structure only; no review or promotion inferred'
    bad=copy.deepcopy(q);bad['target_manifest_sha256']='0'*64;assert check(bad,R)['status']=='NOT_READY';tests['wrong_target']='rejected'
    bad=copy.deepcopy(q);bad['overall']='PASS';assert check(bad,R)['status']=='NOT_READY';tests['PASS_with_unperformed_items']='rejected'
    bad=copy.deepcopy(q);bad['fresh_execution']=True;bad['methods']=['fresh_execution'];assert check(bad,R)['status']=='NOT_READY';tests['execution_without_evidence']='rejected'
    with tempfile.TemporaryDirectory() as t:
        folder=Path(t);(folder/'execution.txt').write_text('fixture')
        bad=copy.deepcopy(q);bad['execution_evidence']=[{'path':'execution.txt','sha256':'0'*64}];assert check(bad,folder)['status']=='NOT_READY';tests['changed_log_hash']='rejected'
        changed=folder/'packet';shutil.copytree(R,changed)
        targets=json.loads((changed/'TARGETS.json').read_text());x=changed/targets['target_directory']/'validate_candidate.py';x.write_bytes(x.read_bytes()+b'\n# modified fixture\n')
        dest=folder/'must_not_be_created'
        run=subprocess.run([sys.executable,str(changed/'review.py'),'--replay','--output-dir',str(dest)],capture_output=True,text=True)
        assert run.returncode!=0 and not dest.exists() and 'package hash mismatch' in run.stderr
        tests['tampered_code']='stopped before replay/output creation'
        extra=folder/'extra';shutil.copytree(R,extra);(extra/'unexpected.py').write_text('raise RuntimeError(\"must never run\")')
        run=subprocess.run([sys.executable,str(extra/'review.py')],capture_output=True,text=True)
        assert run.returncode!=0 and 'unmanifested/missing' in run.stderr
        tests['unmanifested_file']='rejected'
    assert check([],R)['status']=='NOT_READY'
    tests['malformed_return']='rejected'
    print(json.dumps({'classification':'CONSTRUCTOR_HANDOFF_QA_ONLY','status':'PASS','tests':tests,'independent_review':False,'physical_promotion':0},indent=2))
if __name__=='__main__':main()
