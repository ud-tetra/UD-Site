"""Verify packet bytes first. Replay only the named prospective constructor code on request."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,hashlib,json,os,platform,subprocess
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    manifest=json.loads((R/'FILES.json').read_text())
    for f in manifest['files']:
        rel=Path(f['path'])
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('unsafe package path')
        p=R/rel
        if not p.is_file() or p.is_symlink() or sha(p)!=f['sha256']:raise ValueError('package hash mismatch: '+str(rel))
    actual={str(x.relative_to(R)) for x in R.rglob('*') if x.is_file() and x!=R/'FILES.json'}
    expected={x['path'] for x in manifest['files']}
    if actual!=expected:raise ValueError('unmanifested/missing packet files')
    targets=json.loads((R/'TARGETS.json').read_text())
    for f in targets['files']:
        if sha(R/f['path'])!=f['sha256']:raise ValueError('target hash mismatch')
    return targets,len(manifest['files'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--replay',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args()
    targets,n=verify()
    if not args.replay:
        print(json.dumps({'status':'BYTES_VERIFIED','files':n,'code_executed':False}));return
    if args.output_dir is None:ap.error('--replay requires a new --output-dir outside the packet')
    out=args.output_dir.resolve()
    if out==R or R in out.parents:ap.error('output must be outside packet')
    out.mkdir(parents=True,exist_ok=False)
    receipt={'classification':'UNQUALIFIED_REPLAY_NOT_INDEPENDENT_REVIEW','python':platform.python_version(),'target_manifest_sha256':sha(R/'TARGETS.json'),'outputs':[],'physical_promotion':0}
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    for name,script in [('frozen_self_test',R/targets['target_directory']/'self_test.py'),('public_constructor_probes',R/'constructor_probe.py')]:
        result=subprocess.run([sys.executable,str(script)],cwd=R,env=env,text=True,capture_output=True)
        (out/(name+'.stdout.json')).write_text(result.stdout);(out/(name+'.stderr.txt')).write_text(result.stderr)
        if result.returncode:raise RuntimeError(name+' failed; see captured logs')
        payload=json.loads(result.stdout)
        if name=='public_constructor_probes' and payload.get('case_count')!=12:raise ValueError('probe count mismatch')
        for suffix in ['.stdout.json','.stderr.txt']:
            p=out/(name+suffix);receipt['outputs'].append({'path':p.name,'sha256':sha(p)})
    verify() # replay must not change any committed packet file
    (out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':'CONSTRUCTOR_CODE_REPLAY_COMPLETE','receipt':str(out/'REPLAY_RECEIPT.json'),'independence':'not established'}))
if __name__=='__main__':main()
