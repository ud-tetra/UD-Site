"""Check structure and hashes, never reviewer identity, independence or scientific truth."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
def check(doc,folder):
    if not isinstance(doc,dict):return {'status':'NOT_READY','errors':['return must be an object']}
    errors=[];targets=json.loads((R/'TARGETS.json').read_text());expected=hashlib.sha256((R/'TARGETS.json').read_bytes()).hexdigest()
    if doc.get('status')!='SUBMITTED':errors.append('return not submitted')
    if doc.get('target_manifest_sha256')!=expected:errors.append('target manifest mismatch')
    reviewer=doc.get('reviewer',{})
    if not isinstance(reviewer,dict):reviewer={};errors.append('reviewer object')
    for k in ['identifier','relationship_to_constructor','independence_declaration']:
        if not isinstance(reviewer.get(k),str) or not reviewer[k].strip():errors.append('missing reviewer '+k)
    if reviewer.get('kind') not in ['human','external_ai','constructor_team']:errors.append('reviewer kind')
    if not isinstance(doc.get('reviewed_at_utc'),str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z',doc['reviewed_at_utc']):errors.append('UTC review time')
    if not isinstance(doc.get('methods'),list) or not doc['methods'] or not all(x in ['static_inspection','fresh_execution','new_counterexamples','independent_derivation'] for x in doc['methods']):errors.append('methods')
    if type(doc.get('fresh_execution')) is not bool:errors.append('fresh_execution flag')
    if isinstance(doc.get('methods'),list) and bool(doc.get('fresh_execution'))!=('fresh_execution' in doc['methods']):errors.append('execution/method mismatch')
    findings=doc.get('findings',[])
    if not isinstance(findings,list):findings=[];errors.append('findings list')
    items=[x.get('item') for x in findings if isinstance(x,dict)]
    if len(items)!=len(set(items)) or set(items)!=set(targets['required_review_items']):errors.append('review item coverage')
    pending=[];fails=[]
    for x in findings:
        if not isinstance(x,dict):errors.append('finding object');continue
        verdict=x.get('verdict')
        if verdict not in ['PASS','FAIL','OPEN','NOT_REVIEWED']:errors.append('finding verdict')
        if verdict=='NOT_REVIEWED':pending.append(x.get('item'))
        elif not isinstance(x.get('reason'),str) or not x['reason'].strip():errors.append('finding reason')
        if verdict=='FAIL':fails.append(x.get('item'))
    if set(doc.get('unperformed_items',[]))!=set(pending):errors.append('unperformed item mismatch')
    if doc.get('overall') not in ['PASS','FAIL','OPEN']:errors.append('overall verdict')
    if doc.get('overall')=='PASS' and any(x.get('verdict')!='PASS' for x in findings):errors.append('PASS with open or failed findings')
    if fails and doc.get('overall')!='FAIL':errors.append('failed findings require FAIL')
    if not isinstance(doc.get('attestation'),str) or not doc['attestation'].strip():errors.append('missing attestation')
    if type(doc.get('physical_promotion')) is not int or doc['physical_promotion']!=0:errors.append('promotion must stay0')
    evidence=doc.get('execution_evidence',[])
    if not isinstance(evidence,list):evidence=[];errors.append('execution evidence list')
    if doc.get('fresh_execution') and not evidence:errors.append('missing execution evidence')
    for x in evidence:
        if not isinstance(x,dict):errors.append('evidence object');continue
        rel=Path(x.get('path',''));p=folder/rel
        if rel.is_absolute() or '..' in rel.parts or p.is_symlink() or not p.is_file():errors.append('unsafe/missing evidence');continue
        if hashlib.sha256(p.read_bytes()).hexdigest()!=x.get('sha256'):errors.append('evidence hash mismatch')
    return {'status':'RETURN_STRUCTURALLY_COMPLETE' if not errors else 'NOT_READY','errors':errors,'identity_and_independence':'UNVERIFIED_DECLARATIONS','scientific_findings':'NOT_ADJUDICATED','promotion':'NONE'}
if __name__=='__main__':
    try:
        p=Path(sys.argv[1]);doc=json.loads(p.read_text());print(json.dumps(check(doc,p.parent),indent=2))
    except (ValueError,TypeError,KeyError,IndexError):print(json.dumps({'status':'NOT_READY','errors':['malformed return']}))
