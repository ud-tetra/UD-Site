# effective_friedmann_equation.md

Placeholder content for reconstructed repository snapshot.
